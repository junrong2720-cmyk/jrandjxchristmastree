import * as THREE from 'three';
import { ThreeElements } from '@react-three/fiber';

export enum TreeState {
  CHAOS = 'CHAOS',
  FORMED = 'FORMED',
}

export interface GestureData {
  gesture: string; // "Open_Palm", "Closed_Fist", "None"
  handCentroid: { x: number; y: number }; // Normalized 0-1
  isPresent: boolean;
}

export interface DualPos {
  chaos: THREE.Vector3;
  target: THREE.Vector3;
}

// Shader uniforms type
export type Uniforms = {
  [uniform: string]: THREE.IUniform<any>;
};

declare global {
  namespace JSX {
    interface IntrinsicElements extends ThreeElements {}
  }
}
