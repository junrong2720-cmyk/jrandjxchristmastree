import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';

interface PolaroidsProps {
  count: number;
  treeState: TreeState;
}

export const Polaroids: React.FC<PolaroidsProps> = ({ count, treeState }) => {
  const groupRef = useRef<THREE.Group>(null);
  
  // Create static objects for the polaroids to avoid complex instancing with textures (simulated here with colors)
  const items = useMemo(() => {
    return new Array(count).fill(0).map((_, i) => {
      // Chaos
      const r = 16 * Math.cbrt(Math.random());
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      
      const chaosPos = new THREE.Vector3(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      // Target
      const yNorm = Math.random(); 
      const y = yNorm * 10 - 1; 
      const coneRadiusAtY = 6 * (1 - yNorm); 
      const spiralAngle = y * 3.0 + (i * 137.5) * (Math.PI / 180);

      const targetPos = new THREE.Vector3(
        coneRadiusAtY * Math.cos(spiralAngle),
        y,
        coneRadiusAtY * Math.sin(spiralAngle)
      );
      
      return { chaosPos, targetPos, speed: 1.5 + Math.random(), offset: Math.random() * 10 };
    });
  }, [count]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    const targetGlobal = treeState === TreeState.FORMED ? 1.0 : 0.0;
    
    groupRef.current.children.forEach((child, i) => {
      const item = items[i];
      // Store current progress on the object userData to maintain state
      const currentP = child.userData.progress || 0;
      
      const newP = THREE.MathUtils.lerp(currentP, targetGlobal, delta * item.speed * 0.3);
      child.userData.progress = newP;
      
      // Quintic ease out
      const t = newP;
      const ease = 1 - Math.pow(1 - t, 5);

      child.position.lerpVectors(item.chaosPos, item.targetPos, ease);
      
      // Look at center when formed, tumble when chaos
      const targetRot = new THREE.Euler(0, -Math.atan2(child.position.z, child.position.x), 0);
      
      if (treeState === TreeState.FORMED) {
         child.rotation.x = THREE.MathUtils.lerp(child.rotation.x, 0, delta);
         child.rotation.y = THREE.MathUtils.lerp(child.rotation.y, targetRot.y + Math.PI / 2, delta); // Face outward
         child.rotation.z = THREE.MathUtils.lerp(child.rotation.z, Math.sin(state.clock.elapsedTime + i) * 0.1, delta);
      } else {
         child.rotation.x += delta * 0.5;
         child.rotation.y += delta * 0.5;
      }
    });
  });

  return (
    <group ref={groupRef}>
      {items.map((_, i) => (
        <mesh key={i} castShadow userData={{ progress: 0 }}>
          <boxGeometry args={[0.8, 1.0, 0.05]} />
          <meshStandardMaterial color="#fffff0" roughness={0.5} />
          <mesh position={[0, 0.1, 0.03]}>
            <planeGeometry args={[0.7, 0.7]} />
            <meshBasicMaterial color={new THREE.Color().setHSL(Math.random(), 0.8, 0.5)} />
          </mesh>
        </mesh>
      ))}
    </group>
  );
};