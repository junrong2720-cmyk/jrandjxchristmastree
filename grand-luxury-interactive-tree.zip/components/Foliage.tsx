import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';

interface FoliageProps {
  count?: number;
  treeState: TreeState;
}

// Gold and Emerald Shader
const vertexShader = `
  uniform float uTime;
  uniform float uPixelRatio;
  attribute vec3 aTargetPos;
  attribute vec3 aChaosPos;
  uniform float uProgress; // 0 = Chaos, 1 = Formed

  varying vec3 vColor;
  varying float vAlpha;

  // Gold colors
  const vec3 colorGold = vec3(1.0, 0.84, 0.0);
  const vec3 colorEmerald = vec3(0.0, 0.4, 0.2);

  void main() {
    // Cubic easing for smoother transition
    float t = uProgress;
    float ease = t < 0.5 ? 4.0 * t * t * t : 1.0 - pow(-2.0 * t + 2.0, 3.0) / 2.0;

    vec3 pos = mix(aChaosPos, aTargetPos, ease);
    
    // Add some "breathing" movement
    pos.y += sin(uTime + pos.x) * 0.1 * (1.0 - ease); 

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    
    // Size attenuation
    gl_PointSize = (4.0 * uPixelRatio) * (10.0 / -mvPosition.z);

    // Mix colors based on height and randomness
    float mixFactor = pos.y / 15.0 + 0.5;
    vColor = mix(colorEmerald, colorGold, clamp(mixFactor * 0.3, 0.0, 1.0));
    
    // Sparkle effect
    float sparkle = sin(uTime * 5.0 + pos.x * 10.0) * 0.5 + 0.5;
    vColor += vec3(sparkle) * 0.3;
  }
`;

const fragmentShader = `
  varying vec3 vColor;
  
  void main() {
    // Circular particle
    vec2 xy = gl_PointCoord.xy - vec2(0.5);
    float ll = length(xy);
    if (ll > 0.5) discard;

    gl_FragColor = vec4(vColor, 1.0);
  }
`;

export const Foliage: React.FC<FoliageProps> = ({ count = 3000, treeState }) => {
  const meshRef = useRef<THREE.Points>(null);
  
  // Uniforms ref for performance
  const uniforms = useRef({
    uTime: { value: 0 },
    uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
    uProgress: { value: 0 }, // 0 to 1
  });

  const { chaosPositions, targetPositions } = useMemo(() => {
    const chaos = new Float32Array(count * 3);
    const target = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      // Chaos: Random sphere distribution
      const r = 15 * Math.cbrt(Math.random());
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      
      chaos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      chaos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      chaos[i * 3 + 2] = r * Math.cos(phi);

      // Target: Cone Spiral
      // Height 0 to 12
      const yNorm = Math.random(); 
      const y = yNorm * 12 - 2; // -2 to 10
      const coneRadiusAtY = 5 * (1 - yNorm); // Base radius 5
      const spiralAngle = y * 5.0 + Math.random() * 0.5; // Spiral tightness
      
      // Add thickness to the "branches"
      const branchThickness = Math.random() * 0.8; 
      
      target[i * 3] = (coneRadiusAtY + branchThickness) * Math.cos(spiralAngle);
      target[i * 3 + 1] = y;
      target[i * 3 + 2] = (coneRadiusAtY + branchThickness) * Math.sin(spiralAngle);
    }
    return { chaosPositions: chaos, targetPositions: target };
  }, [count]);

  useFrame((state, delta) => {
    if (meshRef.current) {
      uniforms.current.uTime.value += delta;
      
      // Lerp progress
      const targetProgress = treeState === TreeState.FORMED ? 1.0 : 0.0;
      uniforms.current.uProgress.value = THREE.MathUtils.lerp(
        uniforms.current.uProgress.value,
        targetProgress,
        delta * 2.5 // Speed of transition
      );
      
      // Update shader
      (meshRef.current.material as THREE.ShaderMaterial).uniforms.uProgress.value = uniforms.current.uProgress.value;
      (meshRef.current.material as THREE.ShaderMaterial).uniforms.uTime.value = uniforms.current.uTime.value;
    }
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position" // Required for three.js points, but we override in shader with aChaos/aTarget
          count={chaosPositions.length / 3}
          array={chaosPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aChaosPos"
          count={chaosPositions.length / 3}
          array={chaosPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTargetPos"
          count={targetPositions.length / 3}
          array={targetPositions}
          itemSize={3}
        />
      </bufferGeometry>
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms.current}
        transparent={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};