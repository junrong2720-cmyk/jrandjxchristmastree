import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Foliage } from './Foliage';
import { Ornaments } from './Ornaments';
import { Polaroids } from './Polaroids';
import { TreeState } from '../types';

interface LuxuryTreeProps {
  treeState: TreeState;
}

export const LuxuryTree: React.FC<LuxuryTreeProps> = ({ treeState }) => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
        // Slow rotation of the entire tree when formed
        if (treeState === TreeState.FORMED) {
            groupRef.current.rotation.y += 0.002;
        } else {
            // Slight drift in chaos
            groupRef.current.rotation.y += 0.0005;
        }
    }
  });

  return (
    <group ref={groupRef}>
      {/* 1. The Foliage (Needles) */}
      <Foliage count={8000} treeState={treeState} />

      {/* 2. Ornaments - Balls (Red, Gold, Silver) */}
      <Ornaments 
        count={200} 
        type="ball" 
        treeState={treeState} 
        colors={['#880011', '#FFD700', '#C0C0C0']} 
        scale={0.4}
      />
      
      {/* 3. Ornaments - Gifts (Green, Red) */}
      <Ornaments 
        count={50} 
        type="gift" 
        treeState={treeState} 
        colors={['#004422', '#660000', '#FFD700']} 
        scale={0.6}
      />

       {/* 4. Lights - (Warm White) */}
       <Ornaments 
        count={150} 
        type="light" 
        treeState={treeState} 
        colors={['#FFDD88']} 
        scale={0.2}
      />

      {/* 5. Polaroids */}
      <Polaroids count={30} treeState={treeState} />

      {/* Trunk (Only visible when formed essentially, but we can animate it too) */}
      <mesh position={[0, -4, 0]} receiveShadow>
        <cylinderGeometry args={[0.5, 2, 4, 16]} />
        <meshStandardMaterial color="#3e2723" roughness={0.9} />
      </mesh>
      
      {/* Star at top */}
      <mesh position={[0, 10.5, 0]}>
         <octahedronGeometry args={[0.8, 0]} />
         <meshStandardMaterial color="#FFD700" emissive="#FFD700" emissiveIntensity={2} toneMapped={false} />
      </mesh>
    </group>
  );
};