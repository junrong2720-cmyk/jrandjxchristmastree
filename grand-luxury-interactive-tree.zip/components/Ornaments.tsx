import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';

interface OrnamentProps {
  count: number;
  type: 'ball' | 'gift' | 'light';
  treeState: TreeState;
  colors: string[];
  scale: number;
}

export const Ornaments: React.FC<OrnamentProps> = ({ count, type, treeState, colors, scale }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const tempObj = new THREE.Object3D();

  // Data for position calculation
  const data = useMemo(() => {
    const chaosPos = [];
    const targetPos = [];
    const colorArray = [];
    const rotations = [];
    const speeds = [];

    const _color = new THREE.Color();

    for (let i = 0; i < count; i++) {
      // Random Color
      _color.set(colors[Math.floor(Math.random() * colors.length)]);
      colorArray.push(_color.r, _color.g, _color.b);

      // Chaos
      const r = 18 * Math.cbrt(Math.random());
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      chaosPos.push(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      // Target (Tree shape but slightly outside foliage)
      const yNorm = Math.random(); 
      const y = yNorm * 11 - 2; 
      const coneRadiusAtY = 5.2 * (1 - yNorm); 
      const spiralAngle = y * 5.0 + Math.random() * Math.PI * 2; // More spread out angularly

      targetPos.push(
        coneRadiusAtY * Math.cos(spiralAngle),
        y,
        coneRadiusAtY * Math.sin(spiralAngle)
      );

      // Random initial rotation
      rotations.push(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
      
      // Different lerp speeds based on "weight" (Type)
      // Gifts are heavy (slower), Lights are light (faster)
      let speed = 2.0;
      if (type === 'gift') speed = 1.5;
      if (type === 'light') speed = 3.5;
      speeds.push(speed + Math.random());
    }

    return { chaosPos, targetPos, colorArray, rotations, speeds };
  }, [count, colors, type]);

  // Set colors once
  useLayoutEffect(() => {
    if (meshRef.current) {
      const c = new THREE.Color();
      for (let i = 0; i < count; i++) {
        c.setRGB(data.colorArray[i * 3], data.colorArray[i * 3 + 1], data.colorArray[i * 3 + 2]);
        meshRef.current.setColorAt(i, c);
      }
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [data, count]);

  // Current Progress per instance (for staggered animation)
  const currentProgress = useRef(new Float32Array(count).fill(0));

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    const targetP = treeState === TreeState.FORMED ? 1.0 : 0.0;

    for (let i = 0; i < count; i++) {
      // Lerp the progress factor individually
      currentProgress.current[i] = THREE.MathUtils.lerp(
        currentProgress.current[i],
        targetP,
        delta * data.speeds[i] * 0.5
      );

      const t = currentProgress.current[i];
      // Cubic ease
      const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

      const cx = data.chaosPos[i * 3];
      const cy = data.chaosPos[i * 3 + 1];
      const cz = data.chaosPos[i * 3 + 2];

      const tx = data.targetPos[i * 3];
      const ty = data.targetPos[i * 3 + 1];
      const tz = data.targetPos[i * 3 + 2];

      tempObj.position.set(
        THREE.MathUtils.lerp(cx, tx, ease),
        THREE.MathUtils.lerp(cy, ty, ease),
        THREE.MathUtils.lerp(cz, tz, ease)
      );

      // Rotation animation
      tempObj.rotation.set(
        data.rotations[i * 3] + state.clock.elapsedTime * 0.5 * (1 - ease), // Spin more in chaos
        data.rotations[i * 3 + 1] + state.clock.elapsedTime * 0.3,
        data.rotations[i * 3 + 2]
      );
      
      const scaleMult = type === 'light' ? (0.8 + Math.sin(state.clock.elapsedTime * 5 + i)*0.2) : 1;
      tempObj.scale.setScalar(scale * scaleMult);

      tempObj.updateMatrix();
      meshRef.current.setMatrixAt(i, tempObj.matrix);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]} castShadow receiveShadow>
      {type === 'ball' && <sphereGeometry args={[1, 32, 32]} />}
      {type === 'gift' && <boxGeometry args={[1, 1, 1]} />}
      {type === 'light' && <dodecahedronGeometry args={[0.5]} />}
      
      <meshStandardMaterial 
        roughness={type === 'gift' ? 0.3 : 0.1} 
        metalness={type === 'gift' ? 0.1 : 0.9}
        emissive={type === 'light' ? new THREE.Color('#ffaa00') : new THREE.Color(0,0,0)}
        emissiveIntensity={type === 'light' ? 2 : 0}
      />
    </instancedMesh>
  );
};