import { FilesetResolver, HandLandmarker } from "@mediapipe/tasks-vision";

let handLandmarker: HandLandmarker | null = null;
let runningMode: "IMAGE" | "VIDEO" = "VIDEO";

export const initializeHandLandmarker = async (): Promise<void> => {
  const vision = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
  );
  
  handLandmarker = await HandLandmarker.createFromOptions(vision, {
    baseOptions: {
      modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
      delegate: "GPU"
    },
    runningMode: runningMode,
    numHands: 1
  });
};

export const detectGesture = (video: HTMLVideoElement) => {
  if (!handLandmarker) return null;

  if (video.currentTime > 0 && !video.paused && !video.ended) {
    const startTimeMs = performance.now();
    const result = handLandmarker.detectForVideo(video, startTimeMs);

    if (result.landmarks && result.landmarks.length > 0) {
      // Calculate Centroid of the first hand
      const landmarks = result.landmarks[0];
      let xSum = 0, ySum = 0;
      landmarks.forEach(l => {
        xSum += l.x;
        ySum += l.y;
      });
      const centroid = { x: xSum / landmarks.length, y: ySum / landmarks.length };

      // Get Gesture
      let gesture = "None";
      if (result.gestures && result.gestures.length > 0) {
        // High confidence gesture
        if (result.gestures[0][0].score > 0.5) {
            gesture = result.gestures[0][0].categoryName;
        }
      }

      return {
        gesture,
        handCentroid: centroid,
        isPresent: true
      };
    }
  }
  
  return {
    gesture: "None",
    handCentroid: { x: 0.5, y: 0.5 },
    isPresent: false
  };
};