import React, { useEffect, useRef, useState, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Environment, PerspectiveCamera, OrbitControls, Loader, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import * as THREE from 'three';

import { initializeHandLandmarker, detectGesture } from './services/gestureService';
import { LuxuryTree } from './components/LuxuryTree';
import { TreeState } from './types';

// Camera Rig controlled by Hand
const CameraRig = ({ handCentroid }: { handCentroid: { x: number; y: number } }) => {
  const { camera } = useThree();
  const vec = new THREE.Vector3();

  useFrame((state) => {
    // Map hand centroid (0-1) to camera position variance
    // Default pos is [0, 4, 20]
    // X: -10 to 10
    // Y: 0 to 10
    
    // Smoothly interpolate current camera position to target
    const targetX = (handCentroid.x - 0.5) * 20; 
    const targetY = 4 + (handCentroid.y - 0.5) * 10;
    
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, targetX, 0.05);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, targetY, 0.05);
    
    // Always look at center height 4
    camera.lookAt(0, 4, 0);
  });
  
  return null;
};

// Scene Composition
const Scene = ({ treeState, handCentroid }: { treeState: TreeState; handCentroid: { x: number; y: number } }) => {
  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 4, 20]} fov={50} />
      <CameraRig handCentroid={handCentroid} />
      
      {/* Lighting: High Luxury */}
      <ambientLight intensity={0.5} color="#001100" />
      <spotLight position={[10, 20, 10]} angle={0.3} penumbra={1} intensity={2} castShadow color="#fffae0" />
      <pointLight position={[-10, 5, -10]} intensity={1} color="#e5c100" />
      
      <Environment preset="lobby" background={false} />
      
      <group position={[0, 0, 0]}>
         <LuxuryTree treeState={treeState} />
         <Sparkles count={200} scale={12} size={4} speed={0.4} opacity={0.5} color="#FFD700" />
      </group>

      <EffectComposer disableNormalPass>
        <Bloom luminanceThreshold={0.8} mipmapBlur intensity={1.5} radius={0.4} />
        <Vignette eskil={false} offset={0.1} darkness={0.5} />
        <Noise opacity={0.05} />
      </EffectComposer>
    </>
  );
};

export default function App() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [treeState, setTreeState] = useState<TreeState>(TreeState.FORMED);
  const [handCentroid, setHandCentroid] = useState({ x: 0.5, y: 0.5 });
  const [gestureName, setGestureName] = useState("None");
  const requestRef = useRef<number>();

  useEffect(() => {
    const init = async () => {
      try {
        await initializeHandLandmarker();
        
        const constraints = { video: { width: 1280, height: 720 } };
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.addEventListener('loadeddata', () => {
             setLoaded(true);
             predictWebcam();
          });
        }
      } catch (err) {
        console.error("Camera access denied or failed:", err);
        setLoaded(true); // Fallback to allow app to run without camera
      }
    };

    init();
    
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const predictWebcam = (_time?: number) => {
    if (videoRef.current) {
      const result = detectGesture(videoRef.current);
      
      if (result && result.isPresent) {
        // Dampen the centroid update to avoid jitter
        setHandCentroid(prev => ({
            x: prev.x * 0.9 + result.handCentroid.x * 0.1,
            y: prev.y * 0.9 + result.handCentroid.y * 0.1
        }));
        
        setGestureName(result.gesture);
        
        if (result.gesture === "Open_Palm") {
            setTreeState(TreeState.CHAOS);
        } else if (result.gesture === "Closed_Fist") {
            setTreeState(TreeState.FORMED);
        }
      }
    }
    requestRef.current = requestAnimationFrame(predictWebcam);
  };

  return (
    <div className="w-full h-screen relative bg-black">
      {/* Hidden Video for CV */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute top-0 left-0 w-64 h-auto opacity-0 pointer-events-none z-0"
      />

      {/* 3D Canvas */}
      <Canvas shadows dpr={[1, 2]} gl={{ antialias: false }}>
        <Suspense fallback={null}>
          <Scene treeState={treeState} handCentroid={handCentroid} />
        </Suspense>
      </Canvas>
      
      <Loader />

      {/* UI Overlay */}
      <div className="absolute top-0 left-0 w-full p-8 pointer-events-none flex justify-between items-start z-10">
        <div className="flex flex-col space-y-2">
            <h1 className="text-4xl md:text-6xl text-[#FFD700] luxury-text font-bold tracking-widest border-b-4 border-[#005533] pb-2 inline-block">
                THE GRAND TREE
            </h1>
            <p className="text-[#e5c100] font-serif text-lg tracking-wide opacity-80 max-w-md">
                A MAGNIFICENT DISPLAY OF LUXURY AND POWER.
            </p>
        </div>
        
        <div className="flex flex-col items-end text-right space-y-4">
             <div className="bg-[#002211] bg-opacity-80 border border-[#FFD700] p-4 rounded-sm shadow-[0_0_15px_rgba(255,215,0,0.3)] backdrop-blur-sm">
                <h3 className="text-[#FFD700] font-bold mb-2 uppercase tracking-widest text-sm">Controls</h3>
                <ul className="text-xs text-[#aaffaa] space-y-1 font-sans">
                    <li><span className="font-bold text-white">OPEN PALM</span> : UNLEASH CHAOS</li>
                    <li><span className="font-bold text-white">CLOSED FIST</span> : RESTORE ORDER</li>
                    <li><span className="font-bold text-white">HAND MOVE</span> : ADJUST VIEW</li>
                </ul>
             </div>

             <div className="bg-black bg-opacity-50 text-[#FFD700] p-2 text-sm border-l-2 border-[#FFD700]">
                STATUS: <span className={treeState === TreeState.CHAOS ? "text-red-500 font-bold" : "text-emerald-400 font-bold"}>{treeState}</span>
                <br/>
                GESTURE: {gestureName}
             </div>
        </div>
      </div>
      
      <div className="absolute bottom-4 left-0 w-full text-center text-[#FFD700] opacity-40 text-xs tracking-[0.3em]">
          GRAND LUXURY INTERACTIVE CHRISTMAS COLLECTION © 2024
      </div>
    </div>
  );
}
